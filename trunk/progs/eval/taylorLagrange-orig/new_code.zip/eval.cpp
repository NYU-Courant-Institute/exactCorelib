#include <cstdlib>	// needed 

#include "base.h"
#include "evalT2.h"
#include "evalT3.h"
#include "evalT4.h"
#include "evalL3.h"
#include "evalL3cheap.h"
#include "evalL4.h"
#include "evalL4cheap.h"

using namespace std;

//////////////////////////////////////////////////////////////////////////
//
// main program
//
// 	command line arguments:
//    first argument is a string that selects the method to be used for EVAL
//
//      first character selects the kind of method
//
//        t -> generalized Taylor form
//        l -> recursive Lagrange form
//
//      second character selects the degree of exact evaluation
//        2 -> linear (only for Taylor)
//        3 -> quadratic
//        4 -> cubic
//
//      optional third character (only for Lagrange) 
//        c -> for cheaper centered form evaluation of the remainder part
//
//      optional last character
//        v -> verbose output
//        w -> laconic output (only key data as csv)
//
//    examples:
//
//      t3   -> generalized Taylor form with cubic convergence with normal output
//      l4cw -> recursive Lagrange with quartic convergence and cheap remainder part with laconic output
//
// 	   If there are no further arguments, it is assumed that we will
// 		read a polynomial from a file (e.g., text1.txt)
// 	   Else:
// 	   argv[2] = option (int) 
// 		option = 0:  run unit tests
// 		option = 1:  find roots of the golden ratio in [-2,2]
// 		option = 2:
// 	   argv[3] = prec (int)
// 	   argv[4] = eps  (int)
//
int main (int argc, char *argv[]) {
  mpf_set_default_prec(my_mpf_precision);

  if (argc == 1) {    // if no arguments, do nothing
    return -1;
  }
 
  int m = strlen(argv[1]);
  int method = -1;
  
  if ( argv[1][0] == 't' )
    method = 0;
  if ( argv[1][0] == 'l' )
    method = 2;
  if (method < 0)
    return -1;
  
  if (m > 1) {
    if ( argv[1][1] == '2' )
      method += 0;
    if ( argv[1][1] == '3' )
      method += 1;
    if ( argv[1][1] == '4' )
      method += 2;
  }

  if ( (m > 2) && (method > 2) )
    if ( argv[1][2] == 'c' ) {
      method += 2;
    }

  if ( argv[1][m-1] == 'v' )
    verbose = true;
  if ( argv[1][m-1] == 'w' )
    laconic = true;
    
  if (argc == 2) {    // if no further arguments,
    eval* e;
    switch(method) {
    case 0:
      e = new evalT2();
      break;
    case 1:
      e = new evalT3();
      break;
    case 2:
      e = new evalT4();
      break;
    case 3:
      e = new evalL3();
      break;
    case 4:
      e = new evalL4();
      break;
    case 5:
      e = new evalL3cheap();
      break;
    case 6:
      e = new evalL4cheap();
      break;
    }
		e->EVAL();	
		e->stats(20);
		return 0;
  }

  int option = atoi(argv[2]);
  int prec = (argc > 3) ? atoi(argv[3]) : 5;	// output precision
  int eps  = (argc > 4) ? atoi(argv[4]) : 2;	// root precision

  switch(option) {
    case 0: {
      eval* e;
      switch(method) {
      case 0:
        e = new evalT2(0);
        break;
      case 1:
        e = new evalT3(0);
        break;
      case 2:
        e = new evalT4(0);
        break;
      case 3:
        e = new evalL3(0);
        break;
      case 4:
        e = new evalL4(0);
        break;
      case 5:
        e = new evalL3cheap(0);
        break;
      case 6:
        e = new evalL4cheap(0);
        break;
      }
    	e->test();
    	break;
    } // case 0
    case 1: {
      vector<real> v = {-1, -1, 1};
      eval* e;
      switch(method) {
      case 0:
        e = new evalT2(v, interval(-2,2));
        break;
      case 1:
        e = new evalT3(v, interval(-2,2));
        break;
      case 2:
        e = new evalT4(v, interval(-2,2));
        break;
      case 3:
        e = new evalL3(v, interval(-2,2));
        break;
      case 4:
        e = new evalL4(v, interval(-2,2));
        break;
      case 5:
        e = new evalL3cheap(v, interval(-2,2));
        break;
      case 6:
        e = new evalL4cheap(v, interval(-2,2));
        break;
      }
      e->EVAL(eps);
      e->stats(prec);
    	break;
    } // case 1
    default:
      cout << "Option not implemented yet" << endl;
  } //switch
//  return option;
  return 0;
} //main
//
//////////////////////////////////////////////////////////////////////////
